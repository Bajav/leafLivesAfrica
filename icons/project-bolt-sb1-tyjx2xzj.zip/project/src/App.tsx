import React from 'react';
import { Target, Heart, GraduationCap, Building2, Users, HandHeart, Globe2, UserPlus } from 'lucide-react';

const goals = [
  {
    title: 'Combating Poverty',
    description: 'We aim to reduce poverty by addressing its root causes and empowering communities through sustainable development programs and impactful small projects. We strive to improve lives through sustainable initiatives.',
    icon: Target
  },
  {
    title: 'Basic Needs for the Vulnerable',
    description: 'We work to provide essentials such as health, education, water, clothing, and food to poor orphans and needy families by partnering with organizations to enhance services. We strive to improve lives through sustainable initiatives.',
    icon: Heart
  },
  {
    title: 'Supporting Students, Orphans',
    description: 'Our efforts include sponsoring disadvantaged students, orphans, and families to ensure they have access to essential resources for their growth and well-being. We strive to improve lives through sustainable initiatives.',
    icon: GraduationCap
  },
  {
    title: 'Building Vital Infrastructure',
    description: 'Our initiatives focus on constructing mosques, schools, and health centers to strengthen communities and support long-term development. We strive to improve lives through sustainable initiatives.',
    icon: Building2
  },
  {
    title: 'Education and Talent Development',
    description: 'We are dedicated to caring for communities by promoting education, developing talents, and nurturing skills to unlock the full potential of individuals. We strive to improve lives through sustainable initiatives.',
    icon: Users
  },
  {
    title: 'Offering Humanitarian Assistance',
    description: 'Our initiatives focus on constructing mosques, schools, and health centers to strengthen communities and support long-term development. We strive to improve lives through sustainable initiatives.',
    icon: HandHeart
  },
  {
    title: 'Strengthening Global Partnerships',
    description: 'We prioritize collaboration by building strong partnerships between African communities and global entities to foster mutual growth and understanding. We strive to improve lives through sustainable initiatives.',
    icon: Globe2
  },
  {
    title: 'Empowering Women and Youth',
    description: 'We are committed to empowering women and youth by creating opportunities for skill development, education, and entrepreneurship. Our initiatives focus on fostering self-reliance and unlocking their potential.',
    icon: UserPlus
  }
];

function App() {
  return (
    <div className="bg-[#FFFFFF] text-[#333333] min-h-screen">
      <header className="bg-[#3E3E3E] text-[#F8F8F8] py-6 px-4 md:px-8 shadow-lg">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-center">
            Our Goals
          </h1>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-12 md:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {goals.map((goal, index) => (
            <div
              key={index}
              className="bg-[#F8F8F8] rounded-lg p-6 shadow-md hover:shadow-lg transition-shadow duration-300"
            >
              <div className="flex items-center mb-4">
                <goal.icon className="w-6 h-6 mr-3 text-[#3E3E3E]" />
                <h2 className="text-xl font-semibold">{goal.title}</h2>
              </div>
              <p className="text-sm leading-relaxed">{goal.description}</p>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}

export default App;